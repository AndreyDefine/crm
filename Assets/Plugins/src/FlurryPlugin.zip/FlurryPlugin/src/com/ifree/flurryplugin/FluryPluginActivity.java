package com.ifree.flurryplugin;

import com.unity3d.player.UnityPlayerActivity;

import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;

public class FluryPluginActivity extends UnityPlayerActivity{
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.main);

    }

    @Override
    protected void onStart() {
    	super.onStart();
    	//Log.d("UnityPlayerActivity", "UnityPlayerActivity.onStart");
    	FlurryAndroidPlugin.instance().setCurrentContext(this);
    	FlurryAndroidPlugin.instance().onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
        FlurryAndroidPlugin.instance().onStop();
    }  
}
