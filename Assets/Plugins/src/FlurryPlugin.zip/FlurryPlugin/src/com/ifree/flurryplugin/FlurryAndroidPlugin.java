package com.ifree.flurryplugin;

import com.flurry.android.FlurryAgent;
import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerActivity;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

public class FlurryAndroidPlugin {
	private static FlurryAndroidPlugin mInstance;
    private Activity context = null;
    private boolean sessionStarted = false;
    private static String TAG = "FlurryAndroidPlugin";
    private static String PREFS_API_KEY = "apiKey";
    private String apiKey = null;
    private FlurryAndroidPlugin(){

    }

    public static FlurryAndroidPlugin instance(){
        if(mInstance==null){
            mInstance = new FlurryAndroidPlugin();
        }
        return mInstance;
    }

    public void setCurrentContext(Activity context){
        this.context = context;
    }
    
    public Activity getContext(){
    	if(context==null){
    		context = UnityPlayer.currentActivity;
    	}
    	//Log.d(TAG,"getContext "+context);
    	return context;
    }

    public void setApiKey(String apiKey) {
    	if(getContext()==null){
            return;
        }
    	apiKey = apiKey;
    	SharedPreferences sharedPref = getContext().getPreferences(Context.MODE_PRIVATE);
    	SharedPreferences.Editor editor = sharedPref.edit();
    	editor.putString(PREFS_API_KEY, apiKey);
    	editor.commit();    	
    	//Log.d(TAG,"setApiKey");
    }
    
    public String getApiKey(){
    	if(getContext()==null){
            return null;
        }
    	SharedPreferences sharedPref = getContext().getPreferences(Context.MODE_PRIVATE);
    	apiKey = sharedPref.getString(PREFS_API_KEY, null);
    	return apiKey;    	
    }
    
    public boolean onStart() {
    	if(sessionStarted){
    		return true;
    	}
    	//Log.d(TAG,"onStartBeg");
        if(getContext()==null||getApiKey() == null){
            return false;
        }
        sessionStarted = true;
        FlurryAgent.onStartSession(getContext(),getApiKey());
        //Log.d(TAG,"onStart sessionStarted "+sessionStarted);        
        return true;
    }

    public void onStop() {
        if(getContext()==null||!sessionStarted){
            return;
        }
        sessionStarted = false;
        FlurryAgent.onEndSession(getContext());
        //Log.d(TAG,"onStop");
    }

    public boolean logEvent(String msg){
    	if(!sessionStarted){
    		onStart();
    	}
        if(getContext()==null||!sessionStarted){
            return false;
        }
        FlurryAgent.logEvent(msg);
        //Log.d(TAG,"logEvent: "+msg);
        return true;
    }    


}
