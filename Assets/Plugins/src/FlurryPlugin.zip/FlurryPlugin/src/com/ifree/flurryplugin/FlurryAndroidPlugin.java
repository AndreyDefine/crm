package com.ifree.flurryplugin;

import com.flurry.android.FlurryAgent;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

public class FlurryAndroidPlugin {
	private static FlurryAndroidPlugin mInstance;
    private static Activity context = null;
    private static boolean sessionStarted = false;
    private static String TAG = "FlurryAndroidPlugin";
    private static String PREFS_API_KEY = "apiKey";
    private static String apiKey = null;
    private FlurryAndroidPlugin(){

    }

    public static FlurryAndroidPlugin instance(){
        if(mInstance==null){
            mInstance = new FlurryAndroidPlugin();
        }
        return mInstance;
    }

    public void setCurrentContext(Activity context){
        FlurryAndroidPlugin.context = context;
    }

    public void setApiKey(String apiKey) {
    	if(context==null){
            return;
        }
    	FlurryAndroidPlugin.apiKey = apiKey;
    	
    	SharedPreferences sharedPref = context.getPreferences(Context.MODE_PRIVATE);
    	SharedPreferences.Editor editor = sharedPref.edit();
    	editor.putString(PREFS_API_KEY, apiKey);
    	editor.commit();    	
    	//Log.d(TAG,"setApiKey");
    }
    
    public String getApiKey(){
    	if(context==null){
            return null;
        }
    	SharedPreferences sharedPref = context.getPreferences(Context.MODE_PRIVATE);
    	apiKey = sharedPref.getString(PREFS_API_KEY, null);
    	return apiKey;    	
    }
    
    public boolean onStart() {
    	//Log.d(TAG,"onStartBeg");
        if(context==null||getApiKey() == null){
            return false;
        }
        sessionStarted = true;
        FlurryAgent.onStartSession(context,getApiKey());
        //Log.d(TAG,"onStart");
        return true;
    }

    public void onStop() {
        if(context==null||!sessionStarted){
            return;
        }
        sessionStarted = false;
        FlurryAgent.onEndSession(context);
        context = null;
        //Log.d(TAG,"onStop");
    }

    public boolean logEvent(String msg){
    	if(!!sessionStarted){
    		onStart();
    	}
        if(context==null||!sessionStarted){
            return false;
        }
        FlurryAgent.logEvent(msg);
        //Log.d(TAG,"logEvent: "+msg);
        return true;
    }    


}
